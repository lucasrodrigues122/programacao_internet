document.addEventListener('DOMContentLoaded', function() {
    let visitas = localStorage.getItem('visitasDengue') || 0
    visitas++
    localStorage.setItem('visitasDengue', visitas)
    document.getElementById('contadorVisitas').textContent = visitas.toLocaleString()
})

function avaliarSintomas() {
    const sintomas = {
        febre: document.getElementById('febre').checked,
        dorCabeca: document.getElementById('dorCabeca').checked,
        dorOlhos: document.getElementById('dorOlhos').checked,
        dorMuscular: document.getElementById('dorMuscular').checked,
        manchas: document.getElementById('manchas').checked
    }
    
    const sintomasSelecionados = Object.values(sintomas).filter(Boolean).length
    const resultadoDiv = document.getElementById('resultadoAvaliacao')
    
    resultadoDiv.classList.remove('d-none', 'alert-info', 'alert-warning', 'alert-danger')
    
    if (sintomasSelecionados === 0) {
        resultadoDiv.textContent = 'Nenhum sintoma selecionado. Se estiver se sentindo mal, monitore seus sintomas.'
        resultadoDiv.classList.add('alert-info')
    } else if (sintomasSelecionados <= 2) {
        resultadoDiv.innerHTML = '<h6><i class="fas fa-info-circle me-2"></i> Atenção</h6><p>Você apresenta ' + sintomasSelecionados + ' sintomas que podem estar relacionados à dengue.</p><p>Recomenda-se monitorar a evolução dos sintomas e procurar um médico se piorarem.</p>'
        resultadoDiv.classList.add('alert-warning')
    } else if (sintomasSelecionados === 3 || sintomasSelecionados === 4) {
        resultadoDiv.innerHTML = '<h6><i class="fas fa-exclamation-triangle me-2"></i> Cuidado</h6><p>Você apresenta ' + sintomasSelecionados + ' sintomas comuns da dengue.</p><p>Recomenda-se procurar atendimento médico para avaliação.</p><p>Mantenha-se hidratado e evite medicamentos sem orientação.</p>'
        resultadoDiv.classList.add('alert-warning')
    } else {
        resultadoDiv.innerHTML = '<h6><i class="fas fa-exclamation-circle me-2"></i> Atenção Urgente</h6><p>Você apresenta todos os principais sintomas da dengue!</p><p><strong>Procure imediatamente um serviço de saúde.</strong></p><p>Enquanto isso, mantenha repouso e hidratação.</p><p class="mb-0">Evite medicamentos sem orientação médica.</p>'
        resultadoDiv.classList.add('alert-danger')
    }
}

function calcularHidratacao() {
    const peso = parseFloat(document.getElementById('pesoPaciente').value)
    const resultadoDiv = document.getElementById('resultadoHidratacao')
    const quantidadeAgua = document.getElementById('quantidadeAgua')
    const barraProgresso = document.getElementById('barraProgresso')
    
    if (isNaN(peso) || peso <= 0) {
        alert('Por favor, insira um peso válido maior que zero')
        document.getElementById('pesoPaciente').focus()
        return
    }
    
    const minimo = Math.round(peso * 60)
    const ideal = Math.round(peso * 80)
    
    quantidadeAgua.innerHTML = '<strong>' + minimo + 'ml a ' + ideal + 'ml</strong> por dia<small class="d-block">(' + Math.round(minimo/1000) + ' a ' + Math.round(ideal/1000) + ' litros)</small>'
    
    barraProgresso.style.width = '0%'
    setTimeout(() => {
        barraProgresso.style.width = '75%'
        barraProgresso.textContent = Math.round(ideal/1000) + ' litros'
    }, 100)
    
    resultadoDiv.classList.remove('d-none')
}

document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function(e) {
        e.preventDefault()
        
        document.querySelector(this.getAttribute('href')).scrollIntoView({
            behavior: 'smooth'
        })
    })
})

window.addEventListener('scroll', function() {
    const sections = document.querySelectorAll('section')
    const scrollPosition = window.scrollY
    
    sections.forEach(section => {
        const sectionTop = section.offsetTop - 100
        const sectionHeight = section.offsetHeight
        const sectionId = section.getAttribute('id')
        
        if (scrollPosition >= sectionTop && scrollPosition < sectionTop + sectionHeight) {
            document.querySelectorAll('.navbar-nav a').forEach(link => {
                link.classList.remove('active')
                if (link.getAttribute('href') === '#' + sectionId) {
                    link.classList.add('active')
                }
            })
        }
    })
})

const animateOnScroll = function() {
    const elements = document.querySelectorAll('.card, .alert, .titulo')
    
    elements.forEach(element => {
        const elementPosition = element.getBoundingClientRect().top
        const screenPosition = window.innerHeight / 1.2
        
        if (elementPosition < screenPosition) {
            element.style.opacity = '1'
            element.style.transform = 'translateY(0)'
        }
    })
}

window.addEventListener('DOMContentLoaded', function() {
    const elements = document.querySelectorAll('.card, .alert, .titulo')
    
    elements.forEach(element => {
        element.style.opacity = '0'
        element.style.transform = 'translateY(20px)'
        element.style.transition = 'opacity 0.5s ease, transform 0.5s ease'
    })
    
    animateOnScroll()
})

window.addEventListener('scroll', animateOnScroll)