let inputNum1 = document.querySelector("#inputNum1")
let inputNum2 = document.querySelector("#inputNum2")
let inputNum3 = document.querySelector("#inputNum3")
let h3Resultado1 = document.querySelector("#h3Resultado1")
let Calcular1 = document.querySelector("#Calcular1")

function verificarTriangulo() {
    let x = Number(inputNum1.value)
    let y = Number(inputNum2.value)
    let z = Number(inputNum3.value)

    if (x < y + z && y < x + z && z < x + y) {
        
        if (x === y && y === z) {
            h3Resultado1.textContent = "É um triângulo equilátero."
        } else if (x === y || x === z || y === z) {
            h3Resultado1.textContent = "É um triângulo isósceles."
        } else {
            h3Resultado1.textContent = "É um triângulo escaleno."
        }
    } else {
        h3Resultado1.textContent = "Os valores não formam um triângulo."
    }
}

Calcular1.onclick = function () {
    verificarTriangulo()
}

///////////////////////////////////////////////////////////////////////////////////////////

let inputPeso = document.querySelector("#inputPeso")
let inputAltura = document.querySelector("#inputAltura")
let h3Resultado2 = document.querySelector("#h3Resultado2")
let Calcular2 = document.querySelector("#Calcular2")

function calcularIMC() {
  let peso = Number(inputPeso.value)
  let altura = Number(inputAltura.value)
  let imc = peso / (altura * altura)
  let classificacao = ""

  if (imc < 18.5) {
    classificacao = "Abaixo do peso"
  } else if (imc < 25) {
    classificacao = "Peso normal"
  } else if (imc < 30) {
    classificacao = "Sobrepeso"
  } else if (imc < 35) {
    classificacao = "Obesidade grau 1"
  } else if (imc < 40) {
    classificacao = "Obesidade grau 2"
  } else {
    classificacao = "Obesidade grau 3"
  }

  h3Resultado2.innerHTML = "Seu IMC é <b>" + imc.toFixed(2) + "</b><br>" +
     "Classificação: <b>" + classificacao + "</b>"
}

Calcular2.onclick = function() {
  calcularIMC()
}

///////////////////////////////////////////////////////////////////////////////////////////

let inputAno = document.querySelector("#inputAno")
let inputValor = document.querySelector("#inputValor")
let h3Resultado3 = document.querySelector("#h3Resultado3")
let Calcular3 = document.querySelector("#Calcular3")

function calcularImposto() {
  let ano = Number(inputAno.value)
  let valor = Number(inputValor.value)
  let taxa = 0

  if (ano < 1990) {
    taxa = 0.01
  } else {
    taxa = 0.015
  }

  let imposto = valor * taxa

  h3Resultado3.innerHTML = "Ano do carro: <b>" + ano + "</b><br>" +
      "Valor da Tabela: <b>R$ " + valor.toFixed(2) + "</b><br>" +
      "Taxa aplicada: <b>" + (taxa * 100).toFixed(1) + "%</b><br>" +
      "Imposto a pagar: <b>R$ " + imposto.toFixed(2) + "</b>"
}

Calcular3.onclick = function() {
  calcularImposto()
}

///////////////////////////////////////////////////////////////////////////////////////////

let inputSalario = document.querySelector("#inputSalario")
let inputCodigoSalario = document.querySelector("#inputCodigoSalario")
let h3Resultado4 = document.querySelector("#h3Resultado4")
let Calcular4 = document.querySelector("#Calcular4")

function calcularNovoSalario() {
    let salario = Number(inputSalario.value)
    let codigo = Number(inputCodigoSalario.value)
    let percentual = 0
    let cargo = ""

    if (codigo === 101) {
        percentual = 0.10
        cargo = "Gerente"
    } else if (codigo === 102) {
        percentual = 0.20
        cargo = "Engenheiro"
    } else if (codigo === 103) {
        percentual = 0.30
        cargo = "Técnico"
    } else {
        percentual = 0.40
        cargo = "Outro"
    }

    let aumento = salario * percentual
    let novoSalario = salario + aumento

    h3Resultado4.innerHTML = 
        "Cargo: " + cargo + "<br>" +
        "Salário Antigo: R$" + salario.toFixed(2) + "<br>" +
        "Novo Salário: R$" + novoSalario.toFixed(2) + "<br>" +
        "Diferença: R$" + aumento.toFixed(2);
}

Calcular4.onclick = function () {
    calcularNovoSalario()
}

///////////////////////////////////////////////////////////////////////////////////////////

let inputSaldo = document.querySelector("#inputSaldo");
let h3Resultado5 = document.querySelector("#h3Resultado5");
let Calcular5 = document.querySelector("#Calcular5");

function calcularCredito() {
    let saldo = Number(inputSaldo.value);
    let percentual = 0;
    let mensagem = "";

    if (saldo >= 0 && saldo <= 200) {
        percentual = 0;
        mensagem = "Nenhum crédito disponível.";
    } else if (saldo <= 400) {
        percentual = 0.20;
    } else if (saldo <= 600) {
        percentual = 0.30;
    } else {
        percentual = 0.40;
    }

    let credito = saldo * percentual;

    if (percentual > 0) {
        mensagem = "Você tem direito a R$" + credito.toFixed(2) + " de crédito especial.";
    }

    h3Resultado5.innerHTML =
        "Saldo médio: R$" + saldo.toFixed(2) + "<br>" +
        mensagem;
}

Calcular5.onclick = function () {
    calcularCredito();
}

///////////////////////////////////////////////////////////////////////////////////////////

let inputCodigoLanchonete = document.querySelector("#inputCodigoLanchonete")
let inputQuantidade = document.querySelector("#inputQuantidade")
let h3Resultado6 = document.querySelector("#h3Resultado6")
let Calcular6 = document.querySelector("#Calcular6")

function calcularPedido() {
    let codigo = Number(inputCodigoLanchonete.value)
    let quantidade = Number(inputQuantidade.value)
    let preco = 0
    let nome = ""

    if (codigo === 1) {
        nome = "Cachorro Quente"
        preco = 11.00;
    } else if (codigo === 2) {
        nome = "Bauru"
        preco = 8.50;
    } else if (codigo === 3) {
        nome = "Misto Quente"
        preco = 8.00;
    } else if (codigo === 4) {
        nome = "Hamburger"
        preco = 9.00;
    } else if (codigo === 5) {
        nome = "Cheeseburger"
        preco = 10.00;
    } else if (codigo === 6) {
        nome = "Refrigerante"
        preco = 4.50;
    } else {
        h3Resultado6.innerHTML = "Código inválido!"
        return;
    }

    let total = preco * quantidade

    h3Resultado6.innerHTML =
        "Produto: " + nome + "<br>" +
        "Quantidade: " + quantidade + "<br>" +
        "Total a pagar: R$" + total.toFixed(2)
}

Calcular6.onclick = function () {
    calcularPedido()
}

///////////////////////////////////////////////////////////////////////////////////////////

let inputPreco = document.querySelector("#inputPreco")
let inputCodigoVendas = document.querySelector("#inputCodigoVendas")
let h3Resultado7 = document.querySelector("#h3Resultado7")
let Calcular7 = document.querySelector("#Calcular7")

function calcularValorFinal() {
    let preco = Number(inputPreco.value)
    let codigo = inputCodigoVendas.value.toLowerCase()
    let total = 0
    let mensagem = ""

    if (codigo === "a") {
        total = preco * 0.90
        mensagem = "Pagamento à vista em dinheiro ou cheque (10% de desconto)"
    } else if (codigo === "b") {
        total = preco * 0.85;
        mensagem = "Pagamento à vista no cartão (15% de desconto)"
    } else if (codigo === "c") {
        total = preco;
        mensagem = "Pagamento em duas vezes (sem juros)"
    } else if (codigo === "d") {
        total = preco * 1.10;
        mensagem = "Pagamento em duas vezes (com 10% de juros)"
    } else {
        h3Resultado7.innerHTML = "Código inválido!"
        return;
    }

    h3Resultado7.innerHTML =
        mensagem + "<br>" +
        "Preço final a pagar: R$ " + total.toFixed(2)
}

Calcular7.onclick = function () {
    calcularValorFinal()
}

///////////////////////////////////////////////////////////////////////////////////////////

let inputNivel = document.querySelector("#inputNivel")
let inputHoras = document.querySelector("#inputHoras")
let h3Resultado8 = document.querySelector("#h3Resultado8")
let Calcular8 = document.querySelector("#Calcular8")

function calcularSalario() {
    let nivel = Number(inputNivel.value)
    let HorasSemana = Number(inputHoras.value)
    let valorHora = 0

    if (nivel === 1) {
        valorHora = 12
    } else if (nivel === 2) {
        valorHora = 17
    } else if (nivel === 3) {
        valorHora = 25
    } else {
        h3Resultado8.innerHTML = "Nível inválido! Insira 1, 2 ou 3."
        return;
    }

    let salario = valorHora * HorasSemana * 4.5

    h3Resultado8.innerHTML = 
        "Nível do Professor: " + nivel + "<br>" +
        "Horas por semana: " + HorasSemana + "<br>" +
        "Valor por hora: R$" + valorHora.toFixed(2) + "<br>" +
        "Salário Mensal: R$" + salario.toFixed(2)
}

Calcular8.onclick = function () {
    calcularSalario()
}