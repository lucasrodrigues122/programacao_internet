let inputSabor1 = document.querySelector("#inputSabor1");
let inputSabor2 = document.querySelector("#inputSabor2");
let inputSabor3 = document.querySelector("#inputSabor3");
let inputSabor4 = document.querySelector("#inputSabor4");
let inputRefri = document.querySelector("#inputRefri");
let btFinalizar = document.querySelector("#btFinalizar");
let resumoPedido = document.querySelector("#resumoPedido");

function geraPedidoPizza() {
    let qtdRefri = Number(inputRefri.value);
    let qtdSabor = 0;
    let sabores = "Sabores selecionados:<br>";

    if (inputSabor1.value !== "") {
        qtdSabor++;
        sabores += inputSabor1.value + "<br>";
    }
    if (inputSabor2.value !== "") {
        qtdSabor++;
        sabores += inputSabor2.value + "<br>";
    }
    if (inputSabor3.value !== "") {
        qtdSabor++;
        sabores += inputSabor3.value + "<br>";
    }
    if (inputSabor4.value !== "") {
        qtdSabor++;
        sabores += inputSabor4.value + "<br>";
    }

    let totalPizza = qtdSabor * 12;
    let totalRefri = qtdRefri * 7;
    let totalPedido = totalPizza + totalRefri;

    resumoPedido.innerHTML = 
        sabores +
        "Total Pizza: R$ " + totalPizza.toFixed(2) + "<hr>" +
        "Quantidade de Refrigerante: " + qtdRefri + "<br>" +
        "Total Refrigerante: R$ " + totalRefri.toFixed(2) + "<hr>" +
        "Total do Pedido: R$ " + totalPedido.toFixed(2) + "<hr>";
}

btFinalizar.onclick = geraPedidoPizza;