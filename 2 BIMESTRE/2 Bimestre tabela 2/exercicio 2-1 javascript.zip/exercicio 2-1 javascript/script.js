let cotacao = document.querySelector("#cotacao")
let calcular = document.querySelector("#calcular")
let resultado1 = document.querySelector("#resultado1")
let resultado2 = document.querySelector("#resultado2")
let resultado3 = document.querySelector("#resultado3")
let resultado4 = document.querySelector("#resultado4")

calcular.onclick = function(){
    let valor = Number(cotacao.value)

    let aumento1 = valor * 1.01
    let aumento2 = valor * 1.02
    let aumento3 = valor * 1.05
    let aumento4 = valor * 1.10

    resultado1.textContent = "Com aumento de 1%: R$" + aumento1
    resultado2.textContent = "Com aumento de 2% R$" + aumento2
    resultado3.textContent = "Com aumento de 5% R$" + aumento3
    resultado4.textContent = "Com aumento de 10% R$" + aumento4
}