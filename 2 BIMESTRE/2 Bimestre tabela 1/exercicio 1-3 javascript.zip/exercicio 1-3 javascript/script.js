let saldo = document.querySelector("#saldo")
let Button = document.querySelector("#Button")
let resultado = document.querySelector("#resultado")

function calcularSaldoFinal(){
    let num1 = Number(saldo.value)
    resultado.textContent =  num1 * 1.01
}

Button.onclick = function(){
    calcularSaldoFinal()
}