let numero1 = document.querySelector("#numero1")
let Verificar = document.querySelector("#Verificar")
let resultado = document.querySelector("#resultado")

Verificar.onclick = function(){
    let valor = Number(numero1.value)

    if (valor % 2 !== 0){
        resultado.textContent = "O número é ímpar"
    } else {
        resultado.textContent = "O número é par"
    }
}