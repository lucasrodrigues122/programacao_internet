let numero1 = document.querySelector("#numero1")
let numero2 = document.querySelector("#numero2")
let numero3 = document.querySelector("#numero3")
let numero4 = document.querySelector("#numero4")
let comparar = document.querySelector("#comparar")
let resultado = document.querySelector("#resultado")

comparar.onclick = function(){
    let n1 = Number(numero1.value)
    let n2 = Number(numero2.value)
    let n3 = Number(numero3.value)
    let n4 = Number(numero4.value)

    
}