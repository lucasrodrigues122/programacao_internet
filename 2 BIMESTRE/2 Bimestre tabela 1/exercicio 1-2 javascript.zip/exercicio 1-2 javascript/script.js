let numero1 = document.querySelector("#numero1");
let numero2 = document.querySelector("#numero2");
let diminuir = document.querySelector("#diminuir");
let resultado = document.querySelector("#resultado");

function calcularOValorFinal(){
    let num1 = Number(numero1.value)
    let num2 = Number(numero2.value)
    resultado.textContent = num1 * num2
}

diminuir.onclick = function(){
    calcularOValorFinal()
}