let numero1 = document.querySelector("#numero1")
let numero2 = document.querySelector("#numero2")
let comparar = document.querySelector("#comparar")
let resultado = document.querySelector("#resultado")

comparar.onclick = function(){
    let n1 = Number(numero1.value)
    let n2 = Number(numero2.value)

    if (n1 > n2){
        resultado.textContent = "O maior número é:" + n1
    } else if (n2 > n1){
        resultado.textContent = "O maior número é:" + n2
    } else {
        resultado.textContent = "Os dois números são iguais"
    }
}