let conta = document.querySelector("#conta")
let calcular = document.querySelector("#calcular")
let resultado = document.querySelector("#resultado")

calcular.onclick = function(){
    let total = Number(conta.value)
    
    let parteInteira = Math.floor(total / 3)  
    let carlos = parteInteira
    let andre = parteInteira
    let felipe = total - carlos - andre

    resultado.textContent = "Carlos: R$ " + carlos.toFixed(2) + ", André: R$ " + andre.toFixed(2) + ", Felipe: R$ " + felipe.toFixed(2)
}