let cavalos = document.querySelector("#cavalos")
let Calcular = document.querySelector("#Calcular")
let resultado = document.querySelector("#resultado")

Calcular.onclick = function(){
    let QuantDeCavalos = Number(cavalos.value)

    let ferraduras = QuantDeCavalos * 4

    resultado.textContent = "Você precisará de " + ferraduras + " ferraduras para equipar os cavalos."
}