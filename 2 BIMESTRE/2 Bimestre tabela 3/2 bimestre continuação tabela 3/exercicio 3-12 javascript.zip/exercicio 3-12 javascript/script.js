let numero = document.querySelector("#numero")
let calcular = document.querySelector("#calcular")
let centena = document.querySelector("#centena")
let dezena = document.querySelector("#dezena")
let unidade = document.querySelector("#unidade")

calcular.onclick = function(){
    let valor = Number(numero.value)

    if(valor < 0 || valor > 999) {

        
        return
    }

    let c = Math.floor(valor / 100)
    let d = Math.floor((valor % 100) / 10)
    let u = valor % 10

    centena.textContent = "Centena = " + c
    dezena.textContent = "Dezena = " + d
    unidade.textContent = "Unidade " + u
}