let raio = document.querySelector("#raio")
let calcular = document.querySelector("#calcular")
let resultado = document.querySelector("#resultado")

calcular.onclick = function(){
    let r = Number(raio.value)
    let pi = 3.14
    let area = pi * r * r

    resultado.textContent = "A área da pizza é " + area.toFixed(2) + " cm²."
}