let largura = document.querySelector("#largura")
let comprimento = document.querySelector("#comprimento")
let calcular = document.querySelector("#calcular")
let resultado = document.querySelector("#resultado")

calcular.onclick = function(){
    let l = Number(largura.value)
    let c = Number(comprimento.value)

    let area = l * c

    resultado.textContent = "A área do terreno é:" + area + "m²"
}