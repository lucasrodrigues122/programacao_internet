let pao = document.querySelector("#pao")
let broa = document.querySelector("#broa")
let calcular = document.querySelector("#calcular")
let resultadoTotal = document.querySelector("#resultadoTotal")
let resultadoPoupanca = document.querySelector("#resultadoPoupanca")

calcular.onclick = function(){
    let QuantDePao = Number(pao.value)
    let QuantDeBroas = Number(broa.value)

    let total = (QuantDePao * 0.12) + (QuantDeBroas * 1.50)
    let poupanca = total * 0.10

    resultadoTotal.textContent = "Total arrecadado: R$ " + total
    resultadoPoupanca.textContent = "Valor para guardar na poupança (10%): R$ " + poupanca
}