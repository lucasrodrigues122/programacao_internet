let numero1 = document.querySelector("#numero1")
let numero2 = document.querySelector("#numero2")
let calcular = document.querySelector("#calcular")
let resultadoSoma = document.querySelector("#resultadoSoma")
let resultadoSub = document.querySelector("#resultadoSub")
let resultadoMult = document.querySelector("#resultadoMult")
let resultadoDiv = document.querySelector("#resultadoDiv")

calcular.onclick = function(){
    let n1 = Number(numero1.value)
    let n2 = Number(numero2.value)

    let soma = n1 + n2
    let subtracao = n1 - n2
    let multiplicacao = n1 * n2
    let divisao = n1 / n2

    resultadoSoma.textContent = "Soma:" + soma
    resultadoSub.textContent = "Subtração:" + subtracao
    resultadoMult.textContent = "Multiplicação:" + multiplicacao
    resultadoDiv.textContent = "Divisão:" + divisao
}