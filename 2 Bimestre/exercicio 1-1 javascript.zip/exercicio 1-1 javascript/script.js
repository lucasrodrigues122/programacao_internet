let inputNumero1 = document.querySelector("#inputNumero1");
let inputNumero2 = document.querySelector("#inputNumero2");
let Somar = document.querySelector("#Somar");
let resultado = document.querySelector("#resultado");

function somarOsNumero(){
    let num1 = Number(inputNumero1.value)
    let num2 = Number(inputNumero2.value)
    resultado.textContent = num1 + num2
    
}

Somar.onclick = function(){
    somarOsNumero();
}