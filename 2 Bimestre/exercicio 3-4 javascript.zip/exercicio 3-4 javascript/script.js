let nome = document.querySelector("#nome")
let idade = document.querySelector("#idade")
let calcular = document.querySelector("#calcular")
let resultado = document.querySelector("#resultado")

calcular.onclick = function(){
    let NomePessoa = nome.value
    let IdadeAnos = Number(idade.value)

    let DiasDeVida = IdadeAnos * 365

    resultado.textContent = NomePessoa + ", voce ja viveu " + DiasDeVida + " dias."
}