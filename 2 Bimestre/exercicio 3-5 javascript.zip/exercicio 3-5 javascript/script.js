let preco = document.querySelector("#preco")
let valor = document.querySelector("#valor")
let calcular = document.querySelector("#calcular")
let resultado = document.querySelector("#resultado")

calcular.onclick = function(){
    let PrecoLitro = Number(preco.value)
    let ValorPago = Number(valor.value)

    let litros = ValorPago / PrecoLitro

    resultado.textContent = "Você conseguirá abastecer " + litros.toFixed(2) + " litros de gasolina."
}