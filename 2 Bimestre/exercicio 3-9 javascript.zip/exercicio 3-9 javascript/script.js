let x1 = document.querySelector("#x1")
let y1 = document.querySelector("#y1")
let x2 = document.querySelector("#x2")
let y2 = document.querySelector("#y2")
let calcular = document.querySelector("#calcular")
let resultado = document.querySelector("#resultado")

calcular.onclick = function(){
    let PontoX1 = Number(x1.value)
    let PontoY1 = Number(y1.value)
    let PontoX2 = Number(x2.value)
    let PontoY2 = Number(y2.value)

    let distancia = Math.sqrt((PontoX2 - PontoX1) **2 + (PontoY2 - PontoY1) **2 )

    resultado.textContent = "A distância entre os pontos é: " + distancia.toFixed(2)
}