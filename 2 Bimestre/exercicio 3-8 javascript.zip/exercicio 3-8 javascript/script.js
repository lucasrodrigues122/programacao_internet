let pequenas = document.querySelector("#pequenas")
let medias = document.querySelector("#medias")
let grandes = document.querySelector("#grandes")
let calcular = document.querySelector("#calcular")
let resultado = document.querySelector("#resultado")

calcular.onclick = function(){
    let QuantPequenas = Number(pequenas.value)
    let QuantMedias = Number(medias.value)
    let QuantGrandes = Number(grandes.value)

    let total = (QuantPequenas * 10) + (QuantMedias * 12) + (QuantGrandes * 15)

    resultado.textContent = "Valor total arrecadado: R$ " + total.toFixed(2)
}