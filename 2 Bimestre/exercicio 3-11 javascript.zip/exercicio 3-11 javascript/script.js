let salario = document.querySelector("#salario")
let calcular = document.querySelector("#calcular")
let SalarioInicial = document.querySelector("#SalarioInicial")
let SalarioAumento = document.querySelector("#SalarioAumento")
let SalarioFinal = document.querySelector("#SalarioFinal")

calcular.onclick = function(){
    let SalarioOriginal = Number(salario.value)

    let ComAumento = SalarioOriginal * 1.15
    let ComDesconto = ComAumento * 0.92
    
    SalarioInicial.textContent = "Salário Inicial: R$ " + SalarioOriginal.toFixed(2)
    SalarioAumento.textContent = "Salário com aumento: R$ " + ComAumento.toFixed(2)
    SalarioFinal.textContent = "Salário final: R$ " + ComDesconto.toFixed(2)
}