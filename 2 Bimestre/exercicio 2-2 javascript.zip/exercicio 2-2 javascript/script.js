let pessoas = document.querySelector("#pessoas")
let calcular = document.querySelector("#calcular")
let resultadoDoOvo = document.querySelector("#resultadoDoOvo")
let resultadoDoQueijo = document.querySelector("#resultadoDoQueijo")

calcular.onclick = function(){
    let QuantDePessoas = Number(pessoas.value)

    let ovos = QuantDePessoas * 2
    let queijo = QuantDePessoas * 50

    resultadoDoOvo.textContent = "Quantidade de ovos:" + ovos
    resultadoDoQueijo.textContent = "Quantidade de queijo:" + queijo + "g"
}