let dias = document.querySelector("#dias")
let calcular = document.querySelector("#calcular")
let resultado = document.querySelector("#resultado")

calcular.onclick = function(){
    let TotalDosDias = Number(dias.value)
    
    let anos = Math.floor(TotalDosDias / 360)
    let RestoDosDias = TotalDosDias % 360

    let meses = Math.floor(RestoDosDias / 30)
    let DiasFinais = RestoDosDias % 30

    resultado.textContent = "Tempo sem acidentes: " + anos + " ano(s), " + meses + " mês(es) e " + DiasFinais + " dia(s)."
}