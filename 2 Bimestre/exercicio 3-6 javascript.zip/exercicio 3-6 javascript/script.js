let peso = document.querySelector("#peso")
let calcular = document.querySelector("#calcular")
let resultado = document.querySelector("#resultado")

calcular.onclick = function(){
    let PesoPrato = Number(peso.value)
    let PrecoPorQuilo = 12.00

    let total = PesoPrato * PrecoPorQuilo
    
    resultado.textContent = "O valor total a pagar é R$ " + total.toFixed(2)
}