let dias = document.querySelector("#dias")
let meses = document.querySelector("#meses")
let calcular = document.querySelector("#calcular")
let resultado = document.querySelector("#resultado")

calcular.onclick = function(){
    let Dias = Number(dias.value)
    let Meses = Number(meses.value)

    let DiasPassados = (Meses - 1) * 30 + Dias

    resultado.textContent = "Já se passaram " + DiasPassados + " dias desde o início do ano."
}